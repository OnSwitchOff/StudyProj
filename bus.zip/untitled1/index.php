<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 21:47
 */

include "peopleGenerator.php";

$busList=array(1,2,3);
$inList=array(11,21,31);
$outList=array(12,22,33);

?>


<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<meta charset="utf-8">
	<title></title>

</head>
<body>
    <div><a href="">Поехали</a></div>
    <div><a href="">Высадить всех</a></div>
    <div class="info">
        <div class="busList">
            <p>Список пассажиров в автобусе</p>
            <?php
                for($i=0;$i<count($busList);$i++)
                    echo "$busList[$i] <br />";
            ?>
        </div>
        <div class="inList">
            <p>Список пассажиров зашедших в автобус</p>
            <?php
            for($i=0;$i<count($inList);$i++)
                echo "$inList[$i] <br />";
            ?>
        </div>
        <div class="outList">
            <p>Список пассажиров вышедших из автобуса</p>
            <?php
            for($i=0;$i<count($outList);$i++)
                echo "$outList[$i] <br />";
            ?>
        </div>
    </div>
</body>
</html>