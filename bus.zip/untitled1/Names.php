<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 22:57
 */

$Names = array("Ivan","Boris","Lenny","Bob","Jack","Garret");