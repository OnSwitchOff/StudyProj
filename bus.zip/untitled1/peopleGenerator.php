<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 22:14
 */

include "Names.php";

class Man
{
    public $name, $lastStop;
    function __construct()
    {
        $Names = array("Ivan","Boris","Lenny","Bob","Jack","Garret");
        $this->name = $Names[rand(0,count($Names)-1)];
        $this->lastStop = rand(0,9);
    }
    function getInfo()
    {
        echo "<p> Имя: $this->name Target: $this->lastStop</p> ";
    }

    function __destruct()
    {
//        echo "Вызов деструктора";
    }
}

?>

