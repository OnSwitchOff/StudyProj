jQuery(document).ready(function($) {
    $('.lists ol li:not(.busList ol li)').each(function(index, element){
        console.log(index);
        setTimeout(function () {
            console.log($(element));
            $(element).show('slow', function() {})},1000*index);
    });
});
