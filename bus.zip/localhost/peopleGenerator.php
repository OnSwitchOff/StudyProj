<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 22:14
 */
include_once "loadData.php";

class Man
{
    public $name, $lastStop;
    function __construct()
    {
        $Names = loadTxt("names.txt");
        $stops = loadTxt("stops.txt");
        $this->name = $Names[rand(0,count($Names)-1)];
        $this->lastStop = rand(0,count($stops)-1);
    }
    function getInfo()
    {
        $stops = loadTxt("stops.txt");
        return "<p>".$this->name." - ".$stops[$this->lastStop]."</p> ";
    }

    function __destruct()
    {
//        echo "Вызов деструктора";
    }
}

function inListGenerator($maxInCount){
    $inList=[];
    $inCount=rand(0,$maxInCount);
    for ($i=0; $i < $inCount; $i++) {
        $man=new Man();
        array_push($inList,$man);
    }
    return $inList;
}

?>

