<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 06.10.2018
 * Time: 14:40
 */
function loadJson($filePath){
    $Data="";
    if (file_exists ($filePath)){
        $fd = fopen($filePath, 'r') or die("не удалось открыть файл");
        while(!feof($fd))
        {
            $Data .= fgets($fd);
        }
        fclose($fd);
    }
    return json_decode($Data,true);
}

function loadTxt($filePath){
    $String="";
    if (file_exists ( $filePath )){
        $fd = fopen($filePath, 'r') or die("не удалось открыть файл");
        while(!feof($fd))
        {
            $String .= fgets($fd);
        }
        fclose($fd);
    }

    return $Data=explode(", ", $String);
}
