<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 06.10.2018
 * Time: 15:41
 */

;

function outFilter($curStop,$busList){
    return array_filter($busList,function($v) use ($curStop) {
        return $v["lastStop"] == $curStop;
    });
}

function stayFilter($curStop,$busList){
    return array_filter($busList,function($v) use ($curStop) {
        return $v["lastStop"] != $curStop;
    });
}