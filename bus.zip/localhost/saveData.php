<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 06.10.2018
 * Time: 15:14
 */

function saveJson($filePath,$curStop,$busList,$inList,$outList){
    $infoData=json_encode(["curStop"=>$curStop,"busList"=>$busList,"inList"=>$inList,"outList"=>$outList],JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $fd = fopen("Data.json", 'w') or die("не удалось создать файл");
    fwrite($fd, $infoData);
    fclose($fd);
}