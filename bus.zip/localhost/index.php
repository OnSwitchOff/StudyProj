<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 21:47
 */

include "saveData.php";
include "loadData.php";
include "peopleGenerator.php";
include "stay_outFilter.php";

$stops = loadTxt("stops.txt");

if (empty($_GET['action'])){
    $curStop=0;
    $busList=[];
    $outList=[];


    $loadedData=loadJson("Data.json");
    if(!empty($loadedData)){
        $curStop=$loadedData["curStop"];
        $busList=$loadedData["busList"];
        $outList=$loadedData["outList"];
    }

    $inList=inListGenerator(4);
    saveJson("Data.json",$curStop,$busList,$inList,$outList);
}
else{
    $loadedData=loadJson("Data.json");
    if($_GET['action']=='goNext' ){

        if(!empty($loadedData)){
            $curStop=($loadedData["curStop"]==count($stops)-1)?0:($loadedData["curStop"]+1);
            $busList=array_merge($loadedData["busList"],$loadedData["inList"]);
            $outList=outFilter($curStop,$busList);
            $busList=stayFilter($curStop,$busList);
            $inList=inListGenerator(4);

            saveJson("Data.json",$curStop,$busList,$inList,$outList);
        }

    }elseif($_GET['action']=='outAll'){
        !empty($loadedData)?$curStop=$loadedData["curStop"]:$curStop=0;
        $busList=[];
        $outList=[];
        $inList=[];
        saveJson("Data.json",$curStop,$busList,$inList,$outList);
    }
}
//echo "<hr><h1>Cur</h1><pre> ";
//var_dump($curStop);
//echo "</pre><hr><h1>In</h1><pre> ";
//var_dump($inList);
//echo "</pre><hr><h1>BUS</h1><pre> ";
//var_dump($busList);
//echo "</pre><hr><h1>Out</h1><pre> ";
//var_dump($outList);
//echo "</pre><hr>";


?>


<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<meta charset="utf-8">
	<title></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="info">
<!--        <p>Остановка - <span class="stopTitle">--><?//=$stops[$curStop]?><!--</span></p>-->
        <div class="stopsCrumbs">
            <?php
            foreach($stops as $key=>$item){
                if ($key==$curStop)
                    echo "<div class=\"activeStop\">".$item."</div>";
                else
                echo "<div>".$item."</div>";
            }
            ?>
        </div>
        <div class="navigation">
            <div><a href="/index.php?action=goNext">Поехали дальше</a></div>
            <div><a href="/index.php?action=outAll">Высадить всех</a></div>
        </div>
        <div class="lists">
            <div class="busList">
                <h3>Список пассажиров в автобусе:</h3>
                <ol class="stayBusList">
                    <hr>
                    <?php
                    foreach($busList as $item){
//                        echo "<li><p> Имя: ".$item["name"]." Target: ".$stops[$item["lastStop"]]."</p></li>";
                        echo "<li><p>".$item["name"]." - ".$stops[$item["lastStop"]]."</p></li>";
                    }
                    ?>
                    <?php
                    foreach($outList as $item){
                        echo "<li><p>".$item["name"]." - ".$stops[$item["lastStop"]]."</p></li>";
                    }
                    ?>
                    <hr>
                </ol>
<!--                <ol class="outBusList">-->
<!--                    --><?php
//                    foreach($outList as $item){
//                        echo "<li><p>".$item["name"]." - ".$stops[$item["lastStop"]]."</p></li>";
//                    }
//                    ?>
<!--                    <hr>-->
<!--                </ol>-->
<!--                <ol class="inBusList">-->
<!--                    --><?php
//                    foreach($inList as $item){
//                        echo "<li>".$item->getInfo()."</li>";
//                    }
//                    ?>
<!--                    <hr>-->
<!--                </ol>-->

            </div>
            <div class="inList">
                <h3>Список пассажиров на этой остановке:</h3>
                <ol>
                    <hr>
                    <?php
                    foreach($inList as $item){
                        echo "<li>".$item->getInfo()."</li>";
                    }
                    ?>
                    <hr>
                </ol>
            </div>
            <div class="outList">
                <h3>Список пассажиров вышедших из автобуса</h3>
                <ol>
                    <hr>
                    <?php
                    foreach($outList as $item){
                        echo "<li><p>".$item["name"]." - ".$stops[$item["lastStop"]]."</p></li>";
                    }
                    ?>
                    <hr>
                </ol>
            </div>
        </div>
    </div>
    <script
            src="https://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
            crossorigin="anonymous">
    </script>
    <script src="animation.js"></script>
</body>
</html>