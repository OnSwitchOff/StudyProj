let timeData = (function(){

	let mTime=0;
	let sTime=0;
	let stop=false;

	return{
		saveTime: function(){
			localStorage.setItem('x_oTime_m',JSON.stringify(timeData.getmTimeM()));
			localStorage.setItem('x_oTime_s',JSON.stringify(timeData.getmTimeS()));
		},

		loadTime: function(){
			try{
				if(localStorage.getItem('x_oTime_m')!=null){
					mTime=JSON.parse(localStorage.getItem("x_oTime_m"));
					}

				if(localStorage.getItem('x_oTime_s')!=null){
					sTime=JSON.parse(localStorage.getItem("x_oTime_s"));
					}
				}
			catch(ex){};
		},


		resetTime:function (){
			mTime=0;
			sTime=0;
			stop=false;
		},

		timeStr:function(){
			let mStr;
			let sStr;
			mTime<10? mStr='0'+mTime:mStr=mTime;
			sTime<10? sStr='0'+sTime:sStr=sTime;
			return (mStr+":"+sStr)
		},

		stopTime:function(){
			stop=true;
			sTime--;
		},

		flowTime:function(){
			if(sTime==60){
				sTime=0;
				mTime++;
			}
			if(stop==false){
				timeRender();
				sTime++;
				setTimeout('timeData.flowTime()',1000);		
			}	
		},

		getTimeM:function(){
			return mTime;
		},

		getTimeS:function(){
			return sTime;
		},

		getStop:function(){
			return stop;
		}

	}
})();




