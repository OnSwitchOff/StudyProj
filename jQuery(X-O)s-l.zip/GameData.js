const GameData = (function(){
	const x = 1;
	const o = -1;

	let turnX=true;
	let fieldArr = [[0,0,0],[0,0,0],[0,0,0]];
	let turnCounter = 0;
	
	return {
		saveData: function(){
			localStorage.setItem('x_oData_turnX',JSON.stringify(getTurnX()));
			localStorage.setItem('x_oData_fieldArr',JSON.stringify(fieldArr));
			localStorage.setItem('x_oData_turnCounter',JSON.stringify(turnCounter));
		},

		loadData: function(){
			try{
				if(localStorage.getItem("x_oData_turnX")!=null){
				turnX=JSON.parse(localStorage.getItem("x_oData_turnX"));
				}

				if(localStorage.getItem("x_oData_fieldArr")!=null){
				fieldArr=JSON.parse(localStorage.getItem("x_oData_fieldArr"));
				}

				if(localStorage.getItem("x_oData_turnCounter")!=null){
				turnCounter=JSON.parse(localStorage.getItem("x_oData_turnCounter"));
				}
			}catch(ex){};
		},

		resetData: function(){
			turnX=true;
			fieldArr = [[0,0,0],[0,0,0],[0,0,0]];
			turnCounter = 0;
		},

		setMove: function(value,row,col){
			fieldArr[row][col]=value;
		},
		addTurn:function(){
			turnX=!turnX;
			turnCounter++;
		},

		check4Win:function(){
			let result=0;
			for (let i = 0; i < 3; i++) {
			if((fieldArr[i][0]+fieldArr[i][1]+fieldArr[i][2])==3 ||
		   		(fieldArr[0][i]+fieldArr[1][i]+fieldArr[2][i])==3)
				{result=1;}
			else if((fieldArr[i][0]+fieldArr[i][1]+fieldArr[i][2])==-3 ||
		   		(fieldArr[0][i]+fieldArr[1][i]+fieldArr[2][i])==-3)
				{result=-1;}
			}

			if ((fieldArr[0][0]+fieldArr[1][1]+fieldArr[2][2])==3 ||
				(fieldArr[0][2]+fieldArr[1][1]+fieldArr[2][0])==3) 
				{result=1;}
				else if((fieldArr[0][0]+fieldArr[1][1]+fieldArr[2][2])==-3 ||
		 		(fieldArr[0][2]+fieldArr[1][1]+fieldArr[2][0])==-3) 
				{result=-1;}

			return result;
		},

		getFieldArr:function(){
			return fieldArr;
		},

		getTurnX:function(){
			return turnX;
		},

		getTurnCounter:function(){
			return turnCounter;
		},

		getX:function(){
			return x;
		},

		getO:function(){
			return o;
		}
	}
})();
