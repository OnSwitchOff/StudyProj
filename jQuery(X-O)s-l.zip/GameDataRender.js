const StartDataRender=function(){
/**/
	GameData.getFieldArr().forEach(function(row,indexRow)
	{
		row.forEach(function(value,indexCol)
		{
			const block = document.createElement('div');
			block.setAttribute('data-row',indexRow);
			block.setAttribute('data-col',indexCol);
			if(value==GameData.getX()){		
				block.textContent = 'x';		
			}
		else if (value==GameData.getO()){
			block.textContent = 'o';	
		}	
		else{
			block.textContent = '?';
		}
		$('.field').append(block);
		});	
	});	
};

const turnRender=function(e){
	console.log(e.target.textContent);
	if(GameData.getTurnX()){
		e.target.textContent="x"; 
		GameData.setMove(1,e.target.getAttribute("data-row"),e.target.getAttribute("data-col"));
	}
	else{
		e.target.textContent="o"; 
		GameData.setMove(-1,e.target.getAttribute("data-row"),e.target.getAttribute("data-col"));
	};

	GameData.getTurnX()? $('.turn').css('float','left'):$('.turn').css('float','right');
}

const playerXwinRender=function(){
	$('.result').text("p1-win("+timeData.timeStr()+"),click4new");
}

const playerOwinRender=function(){
	$('.result').text("p2-win("+timeData.timeStr()+"),click4new");
}

const drawRender=function(){
	$('.result').text("its a draw("+timeData.timeStr()+"),click4new");
}

const removeField=function(){
	$('.field').empty();
}

const removeResult=function(){
	$('.result').empty();
}

const goNextTurn=function(){
	$('.result').text("Go Next turn");
}
