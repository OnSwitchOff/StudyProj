const timeRender = function(){
	$('.time').text(timeData.timeStr());
}