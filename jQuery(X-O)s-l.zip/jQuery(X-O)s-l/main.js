GameData.loadData();
timeData.loadTime();

const StartGame = function(){
	timeData.flowTime();	
	StartDataRender();
	$(".field>div").one('click',function(e){
		if(e.target.textContent=='?'){
			turnRender(e);
			GameData.addTurn();
			GameData.saveData();
			timeData.saveTime();
			if(GameData.check4Win()==1){
				timeData.stopTime();
				playerXwinRender();	
				GameData.resetData();
				removeField();
				$('.result').one('click',function(){
					timeData.resetTime();
					timeData.flowTime();
					removeResult();
					StartGame();	
				});
			}
			else if (GameData.check4Win()==-1){
				timeData.stopTime();
				playerOwinRender();
				GameData.resetData();
				removeField();
				$('.result').one('click',function(){
					timeData.resetTime();
					timeData.flowTime();
					removeResult();
					StartGame();		
				});
			}
			else if (GameData.check4Win()==0 && GameData.getTurnCounter()==9){
				timeData.stopTime();
				drawRender();
				GameData.resetData();
				removeField();
				$('.result').one('click',function(){
					timeData.resetTime();
					timeData.flowTime();
					removeResult();
					StartGame();	
				});
			}
			else {
				goNextTurn();
			}
		}
	});

};

StartGame();