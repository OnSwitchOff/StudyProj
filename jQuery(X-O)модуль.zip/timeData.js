let timeData = (function(){

	let mTime=0;
	let sTime=0;
	let stop=false;

	return{
		resetTime:function (){
			mTime=0;
			sTime=0;
			stop=false;
		},

		timeStr:function(){
			let mStr;
			let sStr;
			mTime<10? mStr='0'+mTime:mStr=mTime;
			sTime<10? sStr='0'+sTime:sStr=sTime;
			return (mStr+":"+sStr)
		},

		stopTime:function(){
			stop=true;
			sTime--;
		},

		flowTime:function(){
			if(sTime==60){
				sTime=0;
				mTime++;
			}
			if(stop==false){
				timeRender();
				sTime++;
				setTimeout('timeData.flowTime()',1000);		
			}	
		}

	}
})();




