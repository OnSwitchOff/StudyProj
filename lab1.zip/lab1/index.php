<?php
/**
 * Created by PhpStorm.
 * User: Витя
 * Date: 03.10.2018
 * Time: 21:47
 */


?>


<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
	<meta charset="utf-8">
	<title></title>
</head>
<body>
    <?php
        if($_GET['action']=="add"){
            echo '
                <form action="/addUser.php" method="POST">
                    <input type="text" name="login">
                    <input type="password" name="password">
                    <input type="submit" value="add">
                </form>
            ';
        }
        else{
            echo '
            <div class="Menu">
                <div class="show"><a href="/showUsers.php">show</a></div>
                <div class="add"><a href="/?action=add">add</a></div>
            </div>
            ';
        }
    ?>
</body>
</html>


    