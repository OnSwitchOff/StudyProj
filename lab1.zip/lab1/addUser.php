<?php
	$users=[];
	if (file_exists ( "log_pas.txt" )){
        $fd = fopen("log_pas.txt", 'r') or die("не удалось открыть файл");
        while(!feof($fd))
        {
        	$login=explode('|',fgets($fd))[0];
            array_push($users,$login);
        }
        fclose($fd);
    }

    $noMatch=true;
    foreach ($users as $v) {
    	if ($_POST['login']==$v)
    		$noMatch=false;
    };
    
    if($noMatch){
    	$fd = fopen("log_pas.txt", 'a') or die("не удалось открыть файл");
		$str = $_POST['login'].'|'.$_POST['password']."\n";
		fwrite($fd, $str);
		fclose($fd);
        echo "<p>Пользователь ". $_POST['login']." добавлен!</p>";
    }
    else
    echo "<p>Пользователь ". $_POST['login']." уже существует!</p>";
    echo '<div class="back"><a href="/">back</a></div>';
?>

