<?php 
	$users=[];
	$passwords=[];
	if (file_exists ( "log_pas.txt" )){
        $fd = fopen("log_pas.txt", 'r') or die("не удалось открыть файл");
        while(!feof($fd))
        {
        	$data=explode('|',fgets($fd));
            if($data[0]!=""){
                array_push($users,$data[0]);
                array_push($passwords,$data[1]);
            }            
        }
        fclose($fd);
    }
?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
    <h2>Users</h2>  
    <ol>
         <?php 
            for ($i=0; $i <count($users) ; $i++) { 
                echo "
                   <li>".$users[$i]." - ".$passwords[$i]."</li>
                ";
            }
        ?>
    </ol> 
    <div class="back"><a href="/">back</a></div>
</body>
</html>

