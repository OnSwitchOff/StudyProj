var mTime=0;
var sTime=0;
var stop=false;

function resetTime(){
	mTime=0;
	sTime=0;
	stop=false;
}

const timeStr = function(){
	let mStr;
	let sStr;
	mTime<10? mStr='0'+mTime:mStr=mTime;
	sTime<10? sStr='0'+sTime:sStr=sTime;
	return (mStr+":"+sStr);
} 

const timeRender = function(){
	$('.time').text(timeStr());
}

const stopTime = function(){
	stop=true;
	sTime--;
}


function flowTime()
{
	if(sTime==60)
		{
			sTime=0;
			mTime++;
		}
	timeRender();
	if(stop==false){
		sTime++;
		setTimeout('flowTime()',1000);		
	}	
}
flowTime();


