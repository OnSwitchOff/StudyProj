const GameData = (function(){
	const x = 1;
	const o = -1;

	let turnX=true;
	let fieldArr = [[0,0,0],[0,0,0],[0,0,0]];
	let turnCounter = 0;
	
	return {
		saveData: function(){
			localStorage.setItem('x_oData_turnX',JSON.stringify(turnX));
			localStorage.setItem('x_oData_fieldArr',JSON.stringify(fieldArr));
			localStorage.setItem('x_oData_turnCounter',JSON.stringify(turnCounter));
		};

		loadData: function(){
			if(localStorage.getItem("x_oData_turnX")!=null){
				turnX=JSON.parse(localStorage.getItem("x_oData_turnX"));
			}

			if(localStorage.getItem("x_oData_fieldArr")!=null){
				fieldArr=JSON.parse(localStorage.getItem("x_oData_fieldArr"));
			}

			if(localStorage.getItem("x_oData_turnCounter")!=null){
				turnCounter=JSON.parse(localStorage.getItem("x_oData_turnCounter"));
			}
		};

	}
})();
