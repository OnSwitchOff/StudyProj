const x = 1;
const o = -1;

let turnX=false;
let fieldArr = [[0,0,1],[0,0,-1],[1,0,0]];

const Reset=function()
{
	turnX=true;
	fieldArr = [[0,0,0],[0,0,0],[0,0,0]];
	$('.field').empty();
}


let checkTurn = function(){
	turnX? $('.turn').css('float','left'):$('.turn').css('float','right');
}

const render=function(){
fieldArr.forEach(function(row,indexRow){
	console.log(row);
	row.forEach(function(value,indexCol){
		const block = document.createElement('div');
		block.setAttribute('data-row',indexRow);
		block.setAttribute('data-col',indexCol);
		if(value==x){		
			block.textContent = 'x';		
		}
		else if (value==o){
			block.textContent = 'o';	
		}	
		else{
			block.textContent = '?';
		}
		$('.field').append(block);
	});	
});

$(".field>div").one('click',function(e){
	console.log(e.target);
	if(e.target.textContent=='?'){
		if(turnX){
			e.target.textContent="x"; 
			fieldArr[e.target.getAttribute("data-row")][e.target.getAttribute("data-col")]=1;
		}
		else{
			e.target.textContent="o"; 
			fieldArr[e.target.getAttribute("data-row")][e.target.getAttribute("data-col")]=-1;
		};

		if(check4Win()==1)
		{console.log("p1-win");
		Reset();
		render();}
		else if (check4Win()==-1)
		{console.log("p2-win");
		Reset();
		render();}
		else {
			console.log("Go Next turn");
			turnX=!turnX;}
		checkTurn();
	}
});	};

checkTurn();
render();

const check4Win = function(){
	let result=0;
	for (let i = 0; i < 3; i++) {

		console.log(fieldArr[i][0],fieldArr[i][1],fieldArr[i][2]);
		console.log(fieldArr[0][i],fieldArr[1][i],fieldArr[2][i]);

		if((fieldArr[i][0]+fieldArr[i][1]+fieldArr[i][2])==3 ||
		   (fieldArr[0][i]+fieldArr[1][i]+fieldArr[2][i])==3)
		{result=1;}
		else if((fieldArr[i][0]+fieldArr[i][1]+fieldArr[i][2])==-3 ||
		   (fieldArr[0][i]+fieldArr[1][i]+fieldArr[2][i])==-3)
		{result=-1;}
	}

	if ((fieldArr[0][0]+fieldArr[1][1]+fieldArr[2][2])==3 ||
		(fieldArr[0][2]+fieldArr[1][1]+fieldArr[2][0])==3) 
		{result=1;}
	else if((fieldArr[0][0]+fieldArr[1][1]+fieldArr[2][2])==-3 ||
		 (fieldArr[0][2]+fieldArr[1][1]+fieldArr[2][0])==-3) 
		{result=-1;}
	return result;
};


