
const FilterData = (function(){
	let name="filtName";
	let value=[];
	let count=0;

	
	return {
		Data: function(){
		}

	}
})();
