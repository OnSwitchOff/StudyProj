
let req=function(){

	$.ajax({url:"https://api.unsplash.com/photos",
		method:'get',
		success:function(data){			
			data.forEach(function(item){
				let card=document.createElement('div');
				let pic=document.createElement('img');
				pic.setAttribute('src',item.user.profile_image.large);
				console.log(item.user.name);
				console.log(item.user.profile_image.large);
				card.appendChild(pic);
				let name=document.createElement('p');
				name.textContent=item.user.name;
				card.appendChild(name);
				document.querySelector('.cont').appendChild(card);
			});
			return data;
		},
		error:function(error){
			console.log(error);
		},
		data:{
			client_id:'cf49c08b444ff4cb9e4d126b7e9f7513ba1ee58de7906e4360afc1a33d1bf4c0'
		}
	});	
}
	
req();

req();
