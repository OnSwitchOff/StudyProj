const axios = require('axios');

const base="https://api.hh.ru/";

const initVocData=[  
  {'url':"industries",from:['industries']},
  {'url':'specializations',from:['specialization']},
  {'url':"expirience",from:[]},
  {'url':'employment',from:[]}
];

const outVocData=[];

const searchName = function(dataObj,fromArr){
  let result=dataObj;
  for (let i = 0; i < fromArr.length; i++) {    
    result=result[fromArr[i]];
  }
  return result.name;
}

const testObj={game:'Sasha',id:1,industries:{name:'masha',same:'la2'}};

console.log(searchName(testObj,['industries']));


const axiosReq=function(url,index){
   axios.get(url)
    .then(function (response) {
      console.log(response);
      console.log(initVocData);
      console.log(response.map((value)=>{searchName(value,initVocData[index].from)}));
      outVocData.push({vocName:initVocData[index].url,vocValList:response.map((value)=>{searchName(value,initVocData[index].from)})});
    })
    .catch(function (error) {
      console.log(error);
    })
}

for (let i = 0; i < urls.length;i++) {
  if(i==0){
    axiosReq(base+initVocData[i].url,i);
  }
  else{
    .then(axiosReq(base+initVocData[i].url,i));
  }
}

console.log(outVocData);
